#include "render/EffectsRenderer.hpp"
#include <algorithm>
#include <cmath>

namespace tw {

namespace {
constexpr float kPi = 3.14159265358979323846f;

sf::Color withAlpha(const sf::Color& color, sf::Uint8 alpha) {
    return sf::Color(color.r, color.g, color.b, alpha);
}

sf::Uint8 fadeAlpha(float t) {
    const float clamped = std::max(0.0f, std::min(1.0f, t));
    return static_cast<sf::Uint8>(255.0f * clamped);
}

sf::Color teamColor(Team team) {
    switch (team) {
        case Team::Red: return sf::Color(255, 90, 110);
        case Team::Blue: return sf::Color(90, 165, 255);
        case Team::Green: return sf::Color(70, 240, 140);
        case Team::Yellow: return sf::Color(155, 90, 255);
        default: return sf::Color::White;
    }
}

} // namespace

EffectsRenderer::EffectsRenderer() {
    fontLoaded_ = font_.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf");
}

void EffectsRenderer::render(sf::RenderTarget& target,
                             const GameState& state,
                             const std::map<int, sf::Vector2f>& towerPositions,
                             float towerRadius) const {
    const float dt = std::min(0.05f, clock_.restart().asSeconds());

    for (auto it = damageFlash_.begin(); it != damageFlash_.end();) {
        it->second = std::max(0.0f, it->second - dt * 3.0f);
        if (it->second <= 0.001f) {
            it = damageFlash_.erase(it);
        } else {
            ++it;
        }
    }

    for (auto it = healFlash_.begin(); it != healFlash_.end();) {
        it->second = std::max(0.0f, it->second - dt * 2.8f);
        if (it->second <= 0.001f) {
            it = healFlash_.erase(it);
        } else {
            ++it;
        }
    }

    for (const auto& event : state.events()) {
        if (event.towerId() < 0) {
            continue;
        }

        auto it = towerPositions.find(event.towerId());
        if (it == towerPositions.end()) {
            continue;
        }

        const sf::Vector2f center = it->second;

        if (event.type() == EventType::TowerDamaged) {
            damageFlash_[event.towerId()] = std::min(1.0f, damageFlash_[event.towerId()] + 0.9f);

            FloatingText txt;
            txt.position = center + sf::Vector2f(0.0f, -towerRadius * 0.25f);
            txt.velocity = sf::Vector2f(0.0f, -34.0f);
            txt.color = sf::Color(255, 110, 110);
            txt.text = "-" + std::to_string(event.value());
            txt.lifetime = 0.75f;
            txt.maxLifetime = 0.75f;
            txt.size = 22;
            floatingTexts_.push_back(txt);
        } else if (event.type() == EventType::TowerHealed) {
            healFlash_[event.towerId()] = std::min(1.0f, healFlash_[event.towerId()] + 0.85f);

            FloatingText txt;
            txt.position = center + sf::Vector2f(0.0f, -towerRadius * 0.25f);
            txt.velocity = sf::Vector2f(0.0f, -28.0f);
            txt.color = sf::Color(120, 255, 160);
            txt.text = "+" + std::to_string(event.value());
            txt.lifetime = 0.75f;
            txt.maxLifetime = 0.75f;
            txt.size = 22;
            floatingTexts_.push_back(txt);
        } else if (event.type() == EventType::TowerDestroyed) {
            damageFlash_[event.towerId()] = 1.0f;

            FloatingText txt;
            txt.position = center;
            txt.velocity = sf::Vector2f(0.0f, -18.0f);
            txt.color = sf::Color(255, 220, 120);
            txt.text = "DOWN";
            txt.lifetime = 0.95f;
            txt.maxLifetime = 0.95f;
            txt.size = 24;
            floatingTexts_.push_back(txt);
        }
    }

    for (const auto& [towerId, intensity] : damageFlash_) {
        auto it = towerPositions.find(towerId);
        if (it == towerPositions.end()) {
            continue;
        }

        const sf::Vector2f center = it->second;
        const float pulse = 1.0f + 0.06f * std::sin(static_cast<float>(clock_.getElapsedTime().asSeconds()) * 20.0f);

        sf::CircleShape glow((towerRadius + 12.0f) * pulse);
        glow.setOrigin(glow.getRadius(), glow.getRadius());
        glow.setPosition(center);
        glow.setFillColor(sf::Color(255, 90, 90, static_cast<sf::Uint8>(55 * intensity)));
        target.draw(glow);

        sf::CircleShape ring(towerRadius + 18.0f + 8.0f * (1.0f - intensity));
        ring.setOrigin(ring.getRadius(), ring.getRadius());
        ring.setPosition(center);
        ring.setFillColor(sf::Color::Transparent);
        ring.setOutlineThickness(4.0f);
        ring.setOutlineColor(sf::Color(255, 100, 100, static_cast<sf::Uint8>(160 * intensity)));
        target.draw(ring);
    }

    for (const auto& [towerId, intensity] : healFlash_) {
        auto it = towerPositions.find(towerId);
        if (it == towerPositions.end()) {
            continue;
        }

        const sf::Vector2f center = it->second;

        sf::CircleShape glow(towerRadius + 10.0f);
        glow.setOrigin(glow.getRadius(), glow.getRadius());
        glow.setPosition(center);
        glow.setFillColor(sf::Color(90, 255, 150, static_cast<sf::Uint8>(48 * intensity)));
        target.draw(glow);

        sf::CircleShape ring(towerRadius + 14.0f + 6.0f * (1.0f - intensity));
        ring.setOrigin(ring.getRadius(), ring.getRadius());
        ring.setPosition(center);
        ring.setFillColor(sf::Color::Transparent);
        ring.setOutlineThickness(3.0f);
        ring.setOutlineColor(sf::Color(90, 255, 150, static_cast<sf::Uint8>(140 * intensity)));
        target.draw(ring);
    }

    for (auto it = floatingTexts_.begin(); it != floatingTexts_.end();) {
        it->lifetime -= dt;
        it->position += it->velocity * dt;

        if (it->lifetime <= 0.0f) {
            it = floatingTexts_.erase(it);
            continue;
        }

        const float ratio = it->lifetime / it->maxLifetime;

        if (fontLoaded_) {
            sf::Text txt;
            txt.setFont(font_);
            txt.setString(it->text);
            txt.setCharacterSize(it->size);
            txt.setStyle(sf::Text::Bold);
            txt.setFillColor(withAlpha(it->color, fadeAlpha(ratio)));
            const auto bounds = txt.getLocalBounds();
            txt.setOrigin(bounds.left + bounds.width * 0.5f, bounds.top + bounds.height * 0.5f);
            txt.setPosition(it->position);
            target.draw(txt);
        }

        ++it;
    }

    for (const auto& event : state.events()) {
        if (event.towerId() < 0) {
            continue;
        }

        auto it = towerPositions.find(event.towerId());
        if (it == towerPositions.end()) {
            continue;
        }

        sf::Color color = sf::Color(255, 90, 90, 75);
        float ringRadius = towerRadius + 18.0f;
        float ringThickness = 6.0f;
        float glowRadius = ringRadius + 10.0f;
        int sparkCount = 8;

        if (event.type() == EventType::TowerHealed) {
            color = sf::Color(90, 255, 150, 70);
            ringRadius = towerRadius + 16.0f;
            ringThickness = 5.0f;
            glowRadius = ringRadius + 8.0f;
            sparkCount = 6;
        }

        if (event.type() == EventType::TowerDestroyed) {
            color = sf::Color(255, 200, 90, 105);
            ringRadius = towerRadius + 26.0f;
            ringThickness = 8.0f;
            glowRadius = ringRadius + 16.0f;
            sparkCount = 14;
        }

        sf::CircleShape outerGlow(glowRadius + 8.0f);
        outerGlow.setOrigin(outerGlow.getRadius(), outerGlow.getRadius());
        outerGlow.setPosition(it->second);
        outerGlow.setFillColor(sf::Color(color.r, color.g, color.b, static_cast<sf::Uint8>(color.a / 4)));
        target.draw(outerGlow);

        sf::CircleShape ring(ringRadius);
        ring.setOrigin(ring.getRadius(), ring.getRadius());
        ring.setPosition(it->second);
        ring.setFillColor(sf::Color::Transparent);
        ring.setOutlineThickness(ringThickness);
        ring.setOutlineColor(color);
        target.draw(ring);

        for (int i = 0; i < sparkCount; ++i) {
            const float angle = static_cast<float>(i) * (2.0f * kPi / static_cast<float>(sparkCount));
            const sf::Vector2f dir(std::cos(angle), std::sin(angle));
            const sf::Vector2f p = it->second + dir * (towerRadius + 10.0f);

            sf::CircleShape sparkGlow(4.8f);
            sparkGlow.setOrigin(4.8f, 4.8f);
            sparkGlow.setPosition(p);
            sparkGlow.setFillColor(sf::Color(color.r, color.g, color.b, 55));
            target.draw(sparkGlow);

            sf::CircleShape spark(2.4f);
            spark.setOrigin(2.4f, 2.4f);
            spark.setPosition(p);
            spark.setFillColor(sf::Color(color.r, color.g, color.b, 180));
            target.draw(spark);
        }
    }
}

} // namespace tw