#include "audio/AudioManager.hpp"

#include <algorithm>

namespace tw {

AudioManager::AudioManager() {
    spawnLoaded_ = spawnBuffer_.loadFromFile("../assets/sounds/spawn.wav");
    hitLoaded_ = hitBuffer_.loadFromFile("../assets/sounds/hit.wav");
    healLoaded_ = healBuffer_.loadFromFile("../assets/sounds/heal.wav");
    destroyLoaded_ = destroyBuffer_.loadFromFile("../assets/sounds/destroy.wav");

    activeSounds_.reserve(maxActiveSounds_);
}

void AudioManager::cleanupStoppedSounds() {
    activeSounds_.erase(
        std::remove_if(activeSounds_.begin(), activeSounds_.end(),
                       [](const sf::Sound& s) { return s.getStatus() == sf::Sound::Stopped; }),
        activeSounds_.end()
    );
}

void AudioManager::playSound(sf::SoundBuffer& buffer, sf::Int32& lastPlayMs, sf::Int32 cooldownMs, float volume) {
    const sf::Int32 now = audioClock_.getElapsedTime().asMilliseconds();

    if (now - lastPlayMs < cooldownMs) {
        return;
    }

    cleanupStoppedSounds();

    if (activeSounds_.size() >= maxActiveSounds_) {
        return;
    }

    activeSounds_.emplace_back();
    activeSounds_.back().setBuffer(buffer);
    activeSounds_.back().setVolume(volume);
    activeSounds_.back().play();

    lastPlayMs = now;
}

void AudioManager::playEvents(const GameState& state) {
    cleanupStoppedSounds();

    for (const auto& event : state.events()) {
        switch (event.type()) {
            case EventType::TowerDamaged:
                if (hitLoaded_) {
                    playSound(hitBuffer_, lastHitMs_, 55, 45.0f);
                }
                break;

            case EventType::TowerHealed:
                if (healLoaded_) {
                    playSound(healBuffer_, lastHealMs_, 90, 55.0f);
                }
                break;

            case EventType::TowerDestroyed:
                if (destroyLoaded_) {
                    playSound(destroyBuffer_, lastDestroyMs_, 180, 70.0f);
                }
                break;

            case EventType::UnitSpawned:
                if (spawnLoaded_) {
                    playSound(spawnBuffer_, lastSpawnMs_, 40, 28.0f);
                }
                break;

            default:
                break;
        }
    }
}

} // namespace tw