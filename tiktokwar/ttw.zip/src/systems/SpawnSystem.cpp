#include "systems/SpawnSystem.hpp"
#include "utils/IdGenerator.hpp"

namespace tw {

SpawnSystem::SpawnSystem(const Config& config) : config_(config) {}

void SpawnSystem::apply(GameState& state, const std::vector<GameCommand>& commands) {
    for (const auto& command : commands) {
        if (command.type == CommandType::ResetGame) {
            for (auto& tower : state.towers()) {
                tower.reset();
            }
            state.clearUnits();
            state.clearEvents();
            state.setRoundActive(true);
            state.setWinnerId(-1);
            continue;
        }

        if (!state.isRoundActive()) {
            continue;
        }

        if (command.type == CommandType::SpawnHeal) {
            auto* target = state.findTowerById(command.targetTowerId);
            if (target && target->isAlive()) {
                target->heal(config_.healAmount);
                state.events().emplace_back(EventType::TowerHealed, target->id(), target->team(), config_.healAmount);
            }
            continue;
        }

        if (command.type == CommandType::SpawnAttack) {
            auto* source = state.findTowerById(command.sourceTowerId);
            if (!source) continue;

            state.events().emplace_back(
                EventType::UnitSpawned,
                source->id(),
                source->team(),
                1
            );
        }

        for (int i = 0; i < command.count; ++i) {
            if (static_cast<int>(state.units().size()) >= config_.maxUnits) {
                return;
            }

            auto* source = state.findTowerById(command.sourceTowerId);
            auto* target = state.findTowerById(command.targetTowerId);
            if (!source || !target || !source->isAlive() || !target->isAlive()) {
                continue;
            }

            state.units().emplace_back(
                IdGenerator::next(),
                command.team,
                command.sourceTowerId,
                command.targetTowerId,
                config_.unitSpeed,
                config_.unitDamage,
                false
            );
        }
    }
}

} // namespace tw
