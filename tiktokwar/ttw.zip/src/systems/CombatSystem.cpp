#include "systems/CombatSystem.hpp"
#include "utils/Math.hpp"
#include <algorithm>

namespace tw {

namespace {

sf::Vector2f gameplayUnitPosition(const Unit& unit,
                                  const std::map<int, sf::Vector2f>& towerPositions,
                                  float towerRadius,
                                  float unitRadius) {
    const auto source = towerPositions.at(unit.sourceTowerId());
    const auto target = towerPositions.at(unit.targetTowerId());

    const sf::Vector2f dir = math::normalize(target - source);

    const sf::Vector2f baseStart = source + dir * (towerRadius + unitRadius * 1.6f);
    const sf::Vector2f baseEnd = target - dir * (towerRadius + unitRadius * 1.6f);

    return math::lerp(baseStart, baseEnd, unit.progress());
}

sf::Vector2f gameplayTargetEdge(const Unit& unit,
                                const std::map<int, sf::Vector2f>& towerPositions,
                                float towerRadius,
                                float unitRadius) {
    const auto source = towerPositions.at(unit.sourceTowerId());
    const auto target = towerPositions.at(unit.targetTowerId());

    const sf::Vector2f dir = math::normalize(target - source);
    return target - dir * (towerRadius + unitRadius * 1.6f);
}

} // namespace

CombatSystem::CombatSystem(const Config& config) : config_(config) {}

void CombatSystem::update(GameState& state,
                          const std::map<int, sf::Vector2f>& towerPositions,
                          float towerRadius) const {
    auto& units = state.units();

    for (auto& unit : units) {
        if (!unit.isAlive()) {
            continue;
        }

        auto* targetTower = state.findTowerById(unit.targetTowerId());
        if (!targetTower || !targetTower->isAlive()) {
            unit.destroy();
            continue;
        }

        const auto unitPos = gameplayUnitPosition(unit, towerPositions, towerRadius, config_.unitRadius);
        const auto hitPoint = gameplayTargetEdge(unit, towerPositions, towerRadius, config_.unitRadius);

        if (math::distance(unitPos, hitPoint) <= config_.unitRadius * 1.25f || unit.progress() >= 0.999f) {
            targetTower->takeDamage(unit.damage());
            state.events().emplace_back(EventType::TowerDamaged, targetTower->id(), targetTower->team(), unit.damage());

            if (!targetTower->isAlive()) {
                state.events().emplace_back(EventType::TowerDestroyed, targetTower->id(), targetTower->team(), 0);
            }

            unit.destroy();
        }
    }

    units.erase(
        std::remove_if(units.begin(), units.end(), [](const Unit& unit) { return !unit.isAlive(); }),
        units.end()
    );
}

} // namespace tw