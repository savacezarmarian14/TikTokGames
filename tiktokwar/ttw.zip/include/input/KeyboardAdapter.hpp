#pragma once

#include <SFML/Window/Event.hpp>
#include <cstddef>
#include <vector>

#include "core/GameCommand.hpp"

namespace tw {

class KeyboardAdapter {
public:
    std::vector<GameCommand> handleEvent(const sf::Event& event, std::size_t towerCount) const;
};

} // namespace tw