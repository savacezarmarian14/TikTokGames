#pragma once

#include <SFML/Window/Event.hpp>
#include <cstddef>
#include <vector>

#include "core/GameCommand.hpp"
#include "input/KeyboardAdapter.hpp"
#include "input/TikTokAdapter.hpp"

namespace tw {

class InputManager {
public:
    void handleEvent(const sf::Event& event, std::size_t towerCount);
    std::vector<GameCommand> consumeCommands();

private:
    KeyboardAdapter keyboardAdapter_;
    TikTokAdapter tiktokAdapter_;
    std::vector<GameCommand> pending_;
};

} // namespace tw