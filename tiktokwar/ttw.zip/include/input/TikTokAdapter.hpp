#pragma once

#include <vector>
#include "core/GameCommand.hpp"

namespace tw {

class TikTokAdapter {
public:
    std::vector<GameCommand> poll() const;
};

} // namespace tw
