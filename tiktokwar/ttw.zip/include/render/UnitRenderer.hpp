#pragma once

#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>
#include <map>
#include <unordered_map>
#include <vector>

#include "model/GameState.hpp"

namespace tw {

class UnitRenderer {
public:
    void render(sf::RenderTarget& target,
                const GameState& state,
                const std::map<int, sf::Vector2f>& towerPositions,
                float towerRadius,
                float unitRadius) const;

private:
    struct Particle {
        sf::Vector2f position;
        sf::Vector2f velocity;
        sf::Color color;
        float radius = 2.0f;
        float lifetime = 0.0f;
        float maxLifetime = 0.0f;
    };

private:
    sf::Color teamColor(Team team) const;
    void spawnBurst(const sf::Vector2f& pos, const sf::Color& color, bool strong) const;

private:
    mutable sf::Clock clock_;
    mutable std::unordered_map<int, sf::Vector2f> previousPositions_;
    mutable std::vector<Particle> particles_;
};

} // namespace tw