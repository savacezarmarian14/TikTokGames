#pragma once

#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>
#include <map>
#include <unordered_map>
#include <vector>

#include "model/GameState.hpp"

namespace tw {

class EffectsRenderer {
public:
    EffectsRenderer();

    void render(sf::RenderTarget& target,
                const GameState& state,
                const std::map<int, sf::Vector2f>& towerPositions,
                float towerRadius) const;

private:
    struct FloatingText {
        sf::Vector2f position;
        sf::Vector2f velocity;
        sf::Color color;
        std::string text;
        float lifetime = 0.0f;
        float maxLifetime = 0.0f;
        unsigned int size = 18;
    };

private:
    mutable sf::Clock clock_;
    mutable std::vector<FloatingText> floatingTexts_;
    mutable std::unordered_map<int, float> damageFlash_;
    mutable std::unordered_map<int, float> healFlash_;

    sf::Font font_;
    bool fontLoaded_ = false;
};

} // namespace tw