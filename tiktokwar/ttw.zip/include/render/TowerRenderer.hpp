#pragma once

#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>
#include <map>

#include "model/GameState.hpp"

namespace tw {

class TowerRenderer {
public:
    void render(sf::RenderTarget& target,
                const GameState& state,
                const std::map<int, sf::Vector2f>& towerPositions,
                float towerRadius,
                const sf::Font& font) const;

private:
    sf::Color teamColor(Team team, bool alive) const;
    sf::Color hpColor(float ratio) const;

private:
    mutable sf::Clock clock_;
};

} // namespace tw