#pragma once

#include "core/Types.hpp"
#include "core/Constants.hpp"

namespace tw {

class GameEvent {
public:
    GameEvent() = default;
    GameEvent(EventType type, int towerId, Team team, int value = 0);

    EventType type() const;
    int towerId() const;
    Team team() const;
    int value() const;

private:
    EventType type_ = EventType::TowerDamaged;
    int towerId_ = InvalidId;
    Team team_ = Team::None;
    int value_ = 0;
};

} // namespace tw
