#pragma once

#include <string>
#include "core/Types.hpp"

namespace tw {

class Tower {
public:
    Tower() = default;
    Tower(int id, Team team, const std::string& name, int maxHp);

    int id() const;
    Team team() const;
    const std::string& name() const;

    int hp() const;
    int maxHp() const;
    bool isAlive() const;

    void takeDamage(int amount);
    void heal(int amount);
    void reset();

private:
    int id_ = -1;
    Team team_ = Team::None;
    std::string name_;
    int hp_ = 0;
    int maxHp_ = 0;
    bool alive_ = true;
};

} // namespace tw
