#pragma once

#include "core/Types.hpp"

namespace tw {

class Unit {
public:
    Unit() = default;
    Unit(int id, Team owner, int sourceTowerId, int targetTowerId, float speed, int damage, bool healing);

    int id() const;
    Team owner() const;
    int sourceTowerId() const;
    int targetTowerId() const;

    float progress() const;
    void setProgress(float value);

    float speed() const;
    int damage() const;
    bool isHealing() const;

    bool isAlive() const;
    void destroy();

private:
    int id_ = -1;
    Team owner_ = Team::None;
    int sourceTowerId_ = -1;
    int targetTowerId_ = -1;
    float progress_ = 0.0f;
    float speed_ = 0.0f;
    int damage_ = 0;
    bool healing_ = false;
    bool alive_ = true;
};

} // namespace tw
