#pragma once

#include <vector>
#include "model/Tower.hpp"
#include "model/Unit.hpp"
#include "model/GameEvent.hpp"

namespace tw {

class GameState {
public:
    std::vector<Tower>& towers();
    std::vector<Unit>& units();
    std::vector<GameEvent>& events();

    const std::vector<Tower>& towers() const;
    const std::vector<Unit>& units() const;
    const std::vector<GameEvent>& events() const;

    void clearEvents();
    void clearUnits();

    Tower* findTowerById(int id);
    const Tower* findTowerById(int id) const;

    bool isRoundActive() const;
    void setRoundActive(bool active);

    int winnerId() const;
    void setWinnerId(int id);

private:
    std::vector<Tower> towers_;
    std::vector<Unit> units_;
    std::vector<GameEvent> events_;
    bool roundActive_ = true;
    int winnerId_ = -1;
};

} // namespace tw
