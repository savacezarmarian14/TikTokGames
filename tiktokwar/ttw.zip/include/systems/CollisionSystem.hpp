#pragma once

#include <map>
#include <utility>
#include <SFML/System/Vector2.hpp>
#include "model/GameState.hpp"

namespace tw {

class CollisionSystem {
public:
    void update(GameState& state,
                const std::map<int, sf::Vector2f>& towerPositions,
                float towerRadius,
                float unitRadius) const;

private:
    bool sameLaneOppositeDirection(const Unit& a, const Unit& b) const;
};

} // namespace tw