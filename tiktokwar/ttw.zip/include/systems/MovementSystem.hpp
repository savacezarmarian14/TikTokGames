#pragma once

#include "model/GameState.hpp"

namespace tw {

class MovementSystem {
public:
    void update(GameState& state, float dt) const;
};

} // namespace tw
