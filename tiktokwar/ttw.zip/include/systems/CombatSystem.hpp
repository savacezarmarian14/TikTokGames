#pragma once

#include <map>
#include <SFML/System/Vector2.hpp>
#include "core/Config.hpp"
#include "model/GameState.hpp"

namespace tw {

class CombatSystem {
public:
    explicit CombatSystem(const Config& config);
    void update(GameState& state, const std::map<int, sf::Vector2f>& towerPositions, float towerRadius) const;

private:
    const Config& config_;
};

} // namespace tw
