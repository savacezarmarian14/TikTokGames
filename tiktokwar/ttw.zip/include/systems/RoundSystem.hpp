#pragma once

#include "model/GameState.hpp"

namespace tw {

class RoundSystem {
public:
    void update(GameState& state) const;
};

} // namespace tw
