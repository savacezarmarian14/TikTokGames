#pragma once

#include <vector>
#include "core/Config.hpp"
#include "core/GameCommand.hpp"
#include "model/GameState.hpp"

namespace tw {

class SpawnSystem {
public:
    explicit SpawnSystem(const Config& config);
    void apply(GameState& state, const std::vector<GameCommand>& commands);

private:
    const Config& config_;
};

} // namespace tw
