#pragma once

namespace tw {

enum class Team {
    Red = 0,
    Blue,
    Green,
    Yellow,
    None
};

enum class CommandType {
    SpawnAttack,
    SpawnHeal,
    ResetGame
};

enum class EventType {
    TowerDamaged,
    TowerHealed,
    TowerDestroyed,
    UnitDestroyed,
    UnitSpawned,
    RoundEnded
};

} // namespace tw
