#pragma once

#include "core/Types.hpp"
#include "core/Constants.hpp"

namespace tw {

struct GameCommand {
    CommandType type = CommandType::SpawnAttack;
    Team team = Team::None;
    int sourceTowerId = InvalidId;
    int targetTowerId = InvalidId;
    int count = 1;
};

} // namespace tw
