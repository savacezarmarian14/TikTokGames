#pragma once

#include <SFML/Graphics.hpp>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include "audio/AudioManager.hpp"
#include "core/Config.hpp"
#include "core/Types.hpp"
#include "input/InputManager.hpp"
#include "model/GameState.hpp"
#include "render/Renderer.hpp"
#include "systems/CollisionSystem.hpp"
#include "systems/CombatSystem.hpp"
#include "systems/MovementSystem.hpp"
#include "systems/RoundSystem.hpp"
#include "systems/SpawnSystem.hpp"

namespace tw {

class Game {
public:
    explicit Game(std::size_t towerCount);
    void run();

private:
    struct WindowContext {
        Team team = Team::None;
        std::string title;
        sf::RenderWindow window;
        Renderer renderer;

        WindowContext(const Config& config, Team teamValue, const std::string& titleValue)
            : team(teamValue),
              title(titleValue),
              window(),
              renderer(config) {}
    };

private:
    void createWindows();
    void initializeState();
    void resetState();

    void processEvents();
    void processWindowEvents(WindowContext& ctx);
    void update(float dt);
    void render();

    bool allWindowsClosed() const;
    void closeAllWindows();

    sf::Vector2u computeWindowSize() const;

    void toggleAutoplay();
    void updateAutoplay(float dt);
    std::vector<GameCommand> buildAutoplayCommands(float dt);

private:
    Config config_;
    std::size_t towerCount_ = 3;
    std::vector<std::unique_ptr<WindowContext>> windows_;

    GameState state_;
    InputManager inputManager_;

    SpawnSystem spawnSystem_;
    MovementSystem movementSystem_;
    CollisionSystem collisionSystem_;
    CombatSystem combatSystem_;
    RoundSystem roundSystem_;
    AudioManager audioManager_;

    bool autoplayEnabled_ = false;
    bool autoplayBurstMode_ = false;
    float autoplayModeTimer_ = 0.0f;
    float autoplayNextShotTimer_ = 0.0f;

    std::mt19937 rng_;
};

} // namespace tw