#pragma once

namespace tw {

struct Config {
    int windowWidth = 1000;
    int windowHeight = 700;
    unsigned int fpsLimit = 60;

    int towerMaxHp = 200;

    float unitSpeed = 0.42f;
    int unitDamage = 1;
    int healAmount = 1;

    float towerRadius = 48.0f;
    float unitRadius = 7.0f;

    int maxUnits = 500;
};

} // namespace tw