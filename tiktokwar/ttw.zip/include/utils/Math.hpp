#pragma once

#include <SFML/System/Vector2.hpp>

namespace tw {
namespace math {

float length(const sf::Vector2f& v);
float distance(const sf::Vector2f& a, const sf::Vector2f& b);
sf::Vector2f normalize(const sf::Vector2f& v);
sf::Vector2f lerp(const sf::Vector2f& a, const sf::Vector2f& b, float t);
float clamp(float value, float minValue, float maxValue);

} // namespace math
} // namespace tw
