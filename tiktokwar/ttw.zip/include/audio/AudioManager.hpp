#pragma once

#include <SFML/Audio.hpp>
#include <vector>

#include "model/GameState.hpp"

namespace tw {

class AudioManager {
public:
    AudioManager();

    void playEvents(const GameState& state);

private:
    void cleanupStoppedSounds();
    void playSound(sf::SoundBuffer& buffer, sf::Int32& lastPlayMs, sf::Int32 cooldownMs, float volume);

private:
    sf::SoundBuffer spawnBuffer_;
    sf::SoundBuffer hitBuffer_;
    sf::SoundBuffer healBuffer_;
    sf::SoundBuffer destroyBuffer_;

    std::vector<sf::Sound> activeSounds_;
    sf::Clock audioClock_;

    sf::Int32 lastSpawnMs_ = -100000;
    sf::Int32 lastHitMs_ = -100000;
    sf::Int32 lastHealMs_ = -100000;
    sf::Int32 lastDestroyMs_ = -100000;

    bool spawnLoaded_ = false;
    bool hitLoaded_ = false;
    bool healLoaded_ = false;
    bool destroyLoaded_ = false;

    std::size_t maxActiveSounds_ = 24;
};

} // namespace tw